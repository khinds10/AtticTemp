"""
Empty initializer
"""
